# Generated Sanskrit Examples

This folder contains 50 robust canvas-importable example files.

Each example:
- uses current block registry IDs only
- contains 25 blocks and 24 wires
- includes stable `id` and `uid` values
- is designed for import into the canvas loader

The previous example set is preserved in `public/generated-examples-legacy/`.
